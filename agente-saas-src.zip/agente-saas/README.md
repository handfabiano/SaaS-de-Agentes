# Agente SaaS — motor de agente multi-tenant (TypeScript)

Motor configurável: a lógica é a mesma, o que muda por cliente são dados
(system prompt, base de conhecimento, ferramentas, integrações).

## Estrutura
- `src/types/` — tipos centrais (AgentConfig, RunContext, ToolDefinition).
- `src/tools/registry.ts` — catálogo de ferramentas plugáveis. Adicione novas aqui.
- `src/lib/rag.ts` — RAG via `match_chunks` (troque `embedText` pelo seu provedor).
- `src/lib/usage.ts` — cálculo de custo + gravação em `usage_events`.
- `src/agent/loop.ts` — loop central (RAG → modelo → tool-calling → uso).
- `src/agent/loop.smoke.ts` — teste de fumaça sem rede.

## Rodar
```bash
npm install
npm run typecheck
npx tsx src/agent/loop.smoke.ts   # teste de fumaça
```

## Pendências de integração (marcadas no código com TODO)
1. `embedText` em `src/lib/rag.ts`: ligar provedor de embeddings real (dim. 1536).
2. Preços em `src/lib/usage.ts`: confirmar valores oficiais antes de cobrar.
3. Segredos de `tool_configs`: ler via Supabase Vault no backend.
4. Adicionar as ferramentas dos templates (agendar, consultar_jogo, etc.) no registry.
